#!/usr/bin/env bash

python3 dialog_tree/runners/graph_visualizer.py "$@"