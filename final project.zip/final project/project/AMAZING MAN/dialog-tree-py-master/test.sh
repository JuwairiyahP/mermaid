#!/usr/bin/env bash

PYTHONPATH=dialog_tree python3 -m pytest