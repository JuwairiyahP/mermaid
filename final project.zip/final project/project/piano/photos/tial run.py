import pygame
global sys 
import os
pygame.init()

from pygame import mixer
FREE_TRIAL=pygame.font.Font(r"C:\Users\HP-LAP\Desktop\XI\computer\project\uncracked-font\uncracked.otf",190)

WIN = pygame.display.set_mode((800,600)) 
pygame.display.update()
bg_img = pygame.image.load('piano bg.jpg')
bg_img = pygame.transform.scale(bg_img, (800,600))
mc_piano = ''
def dm_piano(message):
  pygame.time.delay(1000)
  WIN.fill((0,0,0))
  text = FREE_TRIAL.render(message,1,(210,105,30))
  WIN.blit(text,(150,230))
  pygame.display.update()
  pygame.time.delay(3000)
def restartpiano():
  conpi=True
  while conpi:
    WIN.fill(BLACK)
    title=UGLY_BITE.render("You lost, press R to",1,WHITE)
    titlerect=title.get_rect()
    titlerect.center=(WIDTH//2,100)
    title1=UGLY_BITE.render("restart the game",1,WHITE)
    title1rect=title1.get_rect()
    title1rect.center=(WIDTH//2,200)
    WIN.blit(title,titlerect)
    WIN.blit(title1,title1rect)
    pygame.display.update()
    events = pygame.event.get()
    for event in events:
      if event.type == pygame.QUIT:
        pygame.quit()
      if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_r:
            os.execl(sys.executable, sys.executable, *sys.argv)

running = True
while running:
    WIN.fill((153,50,204))   
    WIN.blit(bg_img, (0,0))
    pygame.display.update() 
    piano = {1:'mssmrdrmrdd'}
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                do = mixer.Sound('do.wav')
                do.play()
                mc_piano+='d'
            if event.key == pygame.K_r:
                re = mixer.Sound('re.wav')
                re.play()
                mc_piano+='r'
            if event.key == pygame.K_m:
                mi = mixer.Sound('mi.wav')
                mi.play()
                mc_piano+='m'
            if event.key == pygame.K_f:
                fa = mixer.Sound('fa.wav')
                fa.play()
                mc_piano+='f'
            if event.key == pygame.K_s:
                sol = mixer.Sound('sol.mp3')
                sol.play()
                mc_piano+='s'
            if event.key == pygame.K_l:
                la = mixer.Sound('la.wav')
                la.play()
                mc_piano+='l'
            if event.key == pygame.K_t:
                ti = mixer.Sound('ti.wav')
                ti.play()
                mc_piano+='t'
            if event.key == pygame.K_o:
                do = mixer.Sound('do 2.wav')
                do.play()
                mc_piano+='o'       
            if event.key == pygame.K_1:
                if mc_piano == piano[1]:
                    dm_piano("YOU WIN")
                    pygame.quit()
                else:
                    restartpiano()